// ===== PORTFOLIO WEBSITE JAVASCRIPT =====
// Author: Oratile Tladi
// Description: Main JavaScript functionality for portfolio website

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // ===== GLOBAL VARIABLES =====
    let currentProjectIndex = 0;
    let isDragging = false;
    let startX = 0;
    let currentX = 0;
    let translateX = 0;
    
    // ===== DOM ELEMENTS =====
    const galleryTrack = document.querySelector('.gallery-track');
    const projectItems = document.querySelectorAll('.project-item');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const contactForm = document.getElementById('contactForm');
    
    // ===== PROJECT GALLERY FUNCTIONALITY =====
    
    // Initialize gallery
    function initGallery() {
        if (!galleryTrack || projectItems.length === 0) return;
        
        updateGallery();
        setupTouchEvents();
        setupKeyboardEvents();
    }
    
    // Update gallery display
    function updateGallery() {
        // Update project items
        projectItems.forEach((item, index) => {
            item.classList.toggle('active', index === currentProjectIndex);
        });
        
        // Update dots
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentProjectIndex);
        });
        
        // Update gallery track position
        translateX = -currentProjectIndex * 100;
        galleryTrack.style.transform = `translateX(${translateX}%)`;
    }
    
    // Go to next project
    function nextProject() {
        currentProjectIndex = (currentProjectIndex + 1) % projectItems.length;
        updateGallery();
    }
    
    // Go to previous project
    function prevProject() {
        currentProjectIndex = currentProjectIndex === 0 ? projectItems.length - 1 : currentProjectIndex - 1;
        updateGallery();
    }
    
    // Go to specific project
    function goToProject(index) {
        if (index >= 0 && index < projectItems.length) {
            currentProjectIndex = index;
            updateGallery();
        }
    }
    
    // ===== TOUCH AND MOUSE EVENTS =====
    
    // Setup touch events for mobile
    function setupTouchEvents() {
        if (!galleryTrack) return;
        
        // Touch events
        galleryTrack.addEventListener('touchstart', handleTouchStart);
        galleryTrack.addEventListener('touchmove', handleTouchMove);
        galleryTrack.addEventListener('touchend', handleTouchEnd);
        
        // Mouse events for desktop
        galleryTrack.addEventListener('mousedown', handleMouseDown);
        galleryTrack.addEventListener('mousemove', handleMouseMove);
        galleryTrack.addEventListener('mouseup', handleMouseUp);
        galleryTrack.addEventListener('mouseleave', handleMouseUp);
        
        // Prevent context menu on long press
        galleryTrack.addEventListener('contextmenu', e => e.preventDefault());
    }
    
    // Touch start handler
    function handleTouchStart(e) {
        isDragging = true;
        startX = e.touches[0].clientX;
        currentX = startX;
        translateX = -currentProjectIndex * 100;
        
        galleryTrack.style.transition = 'none';
        galleryTrack.style.cursor = 'grabbing';
    }
    
    // Touch move handler
    function handleTouchMove(e) {
        if (!isDragging) return;
        
        e.preventDefault();
        currentX = e.touches[0].clientX;
        const diffX = currentX - startX;
        const moveX = (diffX / window.innerWidth) * 100;
        
        galleryTrack.style.transform = `translateX(${translateX + moveX}%)`;
    }
    
    // Touch end handler
    function handleTouchEnd() {
        if (!isDragging) return;
        
        isDragging = false;
        galleryTrack.style.transition = 'transform 0.5s ease';
        galleryTrack.style.cursor = 'grab';
        
        const diffX = currentX - startX;
        const threshold = window.innerWidth * 0.2; // 20% threshold
        
        if (Math.abs(diffX) > threshold) {
            if (diffX > 0) {
                prevProject();
            } else {
                nextProject();
            }
        } else {
            // Snap back to current position
            updateGallery();
        }
    }
    
    // Mouse down handler
    function handleMouseDown(e) {
        isDragging = true;
        startX = e.clientX;
        currentX = startX;
        translateX = -currentProjectIndex * 100;
        
        galleryTrack.style.transition = 'none';
        galleryTrack.style.cursor = 'grabbing';
    }
    
    // Mouse move handler
    function handleMouseMove(e) {
        if (!isDragging) return;
        
        currentX = e.clientX;
        const diffX = currentX - startX;
        const moveX = (diffX / window.innerWidth) * 100;
        
        galleryTrack.style.transform = `translateX(${translateX + moveX}%)`;
    }
    
    // Mouse up handler
    function handleMouseUp() {
        if (!isDragging) return;
        
        isDragging = false;
        galleryTrack.style.transition = 'transform 0.5s ease';
        galleryTrack.style.cursor = 'grab';
        
        const diffX = currentX - startX;
        const threshold = window.innerWidth * 0.2; // 20% threshold
        
        if (Math.abs(diffX) > threshold) {
            if (diffX > 0) {
                prevProject();
            } else {
                nextProject();
            }
        } else {
            // Snap back to current position
            updateGallery();
        }
    }
    
    // ===== KEYBOARD EVENTS =====
    
    function setupKeyboardEvents() {
        document.addEventListener('keydown', function(e) {
            switch(e.key) {
                case 'ArrowLeft':
                    e.preventDefault();
                    prevProject();
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    nextProject();
                    break;
                case ' ':
                    e.preventDefault();
                    nextProject();
                    break;
            }
        });
    }
    
    // ===== EVENT LISTENERS =====
    
    // Gallery navigation buttons
    if (prevBtn) {
        prevBtn.addEventListener('click', prevProject);
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', nextProject);
    }
    
    // Gallery dots
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => goToProject(index));
    });
    
    // View Project button
    const viewProjectBtn = document.querySelector('.view-project-btn');
    if (viewProjectBtn) {
        viewProjectBtn.addEventListener('click', handleViewProject);
    }
    
    // ===== SMOOTH SCROLLING =====
    
    // Smooth scroll for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // ===== PROJECT VIEWING =====
    
    // Handle view project button click
    function handleViewProject() {
        const currentProject = projectItems[currentProjectIndex];
        if (!currentProject) return;
        
        // Get project details
        const projectTitle = currentProject.querySelector('.project-overlay h3')?.textContent || 'Project';
        const projectDescription = currentProject.querySelector('.project-overlay p')?.textContent || 'Project description';
        
        // Show project details in a modal or notification
        showProjectModal(projectTitle, projectDescription);
        
        // Alternative: You can redirect to a project page or open in new tab
        // window.open(`/projects/${currentProjectIndex + 1}`, '_blank');
    }
    
    // Show project modal
    function showProjectModal(title, description) {
        // Remove existing modal
        const existingModal = document.querySelector('.project-modal');
        if (existingModal) {
            existingModal.remove();
        }
        
        // Create modal element
        const modal = document.createElement('div');
        modal.className = 'project-modal';
        modal.innerHTML = `
            <div class="modal-overlay"></div>
            <div class="modal-content">
                <div class="modal-header">
                    <h3>${title}</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <p>${description}</p>
                    <div class="modal-actions">
                        <button class="modal-btn primary">View Live Demo</button>
                        <button class="modal-btn secondary">View Source Code</button>
                    </div>
                </div>
            </div>
        `;
        
        // Add modal styles
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
        `;
        
        // Add to page
        document.body.appendChild(modal);
        
        // Add modal styles
        const modalStyles = `
            .project-modal .modal-overlay {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.8);
                backdrop-filter: blur(10px);
            }
            
            .project-modal .modal-content {
                position: relative;
                background: rgba(26, 26, 26, 0.95);
                backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 20px;
                padding: 2rem;
                max-width: 500px;
                width: 90%;
                max-height: 80vh;
                overflow-y: auto;
                animation: modalSlideIn 0.3s ease-out;
            }
            
            .project-modal .modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 1.5rem;
                padding-bottom: 1rem;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }
            
            .project-modal .modal-header h3 {
                margin: 0;
                font-size: 1.5rem;
                color: #ffffff;
            }
            
            .project-modal .modal-close {
                background: none;
                border: none;
                color: #ffffff;
                font-size: 1.5rem;
                cursor: pointer;
                padding: 0;
                width: 30px;
                height: 30px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.3s ease;
            }
            
            .project-modal .modal-close:hover {
                background: rgba(255, 255, 255, 0.1);
            }
            
            .project-modal .modal-body p {
                margin-bottom: 2rem;
                line-height: 1.6;
                color: #cccccc;
            }
            
            .project-modal .modal-actions {
                display: flex;
                gap: 1rem;
                flex-wrap: wrap;
            }
            
            .project-modal .modal-btn {
                padding: 0.75rem 1.5rem;
                border: none;
                border-radius: 10px;
                font-size: 0.9rem;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                flex: 1;
                min-width: 120px;
            }
            
            .project-modal .modal-btn.primary {
                background: linear-gradient(45deg, #ffffff, #cccccc);
                color: #000000;
            }
            
            .project-modal .modal-btn.secondary {
                background: rgba(255, 255, 255, 0.1);
                color: #ffffff;
                border: 1px solid rgba(255, 255, 255, 0.2);
            }
            
            .project-modal .modal-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
            }
            
            @keyframes modalSlideIn {
                from {
                    opacity: 0;
                    transform: translateY(-50px) scale(0.9);
                }
                to {
                    opacity: 1;
                    transform: translateY(0) scale(1);
                }
            }
            
            @media (max-width: 768px) {
                .project-modal .modal-content {
                    margin: 1rem;
                    padding: 1.5rem;
                }
                
                .project-modal .modal-actions {
                    flex-direction: column;
                }
            }
        `;
        
        // Inject modal styles
        const styleSheet = document.createElement('style');
        styleSheet.textContent = modalStyles;
        document.head.appendChild(styleSheet);
        
        // Close modal functionality
        const closeBtn = modal.querySelector('.modal-close');
        const overlay = modal.querySelector('.modal-overlay');
        
        closeBtn.addEventListener('click', () => removeProjectModal(modal));
        overlay.addEventListener('click', () => removeProjectModal(modal));
        
        // Close on escape key
        document.addEventListener('keydown', function closeOnEscape(e) {
            if (e.key === 'Escape') {
                removeProjectModal(modal);
                document.removeEventListener('keydown', closeOnEscape);
            }
        });
        
        // Button actions
        const liveDemoBtn = modal.querySelector('.modal-btn.primary');
        const sourceCodeBtn = modal.querySelector('.modal-btn.secondary');
        
        liveDemoBtn.addEventListener('click', () => {
            showNotification('Live demo link would open here', 'info');
            // You can replace this with actual project URLs
            // window.open('https://your-project-demo.com', '_blank');
        });
        
        sourceCodeBtn.addEventListener('click', () => {
            showNotification('Source code link would open here', 'info');
            // You can replace this with actual GitHub/source code URLs
            // window.open('https://github.com/yourusername/project', '_blank');
        });
    }
    
    // Remove project modal
    function removeProjectModal(modal) {
        modal.style.animation = 'modalSlideOut 0.3s ease-in';
        
        // Add slide out animation
        const slideOutStyles = `
            @keyframes modalSlideOut {
                to {
                    opacity: 0;
                    transform: translateY(-50px) scale(0.9);
                }
            }
        `;
        
        const styleSheet = document.createElement('style');
        styleSheet.textContent = slideOutStyles;
        document.head.appendChild(styleSheet);
        
        setTimeout(() => {
            if (modal.parentNode) {
                modal.remove();
            }
        }, 300);
    }
    
    // ===== FORM HANDLING =====
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleFormSubmit();
        });
    }
    
    // Handle form submission
    function handleFormSubmit() {
        const formData = new FormData(contactForm);
        const data = Object.fromEntries(formData);
        
        // Basic validation
        if (!data.name || !data.email || !data.message) {
            showNotification('Please fill in all required fields.', 'error');
            return;
        }
        
        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            showNotification('Please enter a valid email address.', 'error');
            return;
        }
        
        // Simulate form submission (replace with actual backend integration)
        showNotification('Message sent successfully!', 'success');
        contactForm.reset();
        
        // Here you would typically send the data to your backend
        console.log('Form data:', data);
    }
    
    // ===== NOTIFICATIONS =====
    
    function showNotification(message, type = 'info') {
        // Remove existing notifications
        const existingNotification = document.querySelector('.notification');
        if (existingNotification) {
            existingNotification.remove();
        }
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-message">${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#4CAF50' : type === 'error' ? '#f44336' : '#2196F3'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
            z-index: 10000;
            transform: translateX(100%);
            transition: transform 0.3s ease;
            max-width: 300px;
        `;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            removeNotification(notification);
        }, 5000);
        
        // Close button functionality
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.addEventListener('click', () => removeNotification(notification));
    }
    
    function removeNotification(notification) {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }
    
    // ===== SCROLL ANIMATIONS =====
    
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.project-showcase, .contact-container, .hero-content').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        observer.observe(el);
    });
    
    // ===== NAVIGATION HIGHLIGHTING =====
    
    // Highlight current section in navigation
    function updateNavigation() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-link');
        
        let currentSection = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.offsetHeight;
            const scrollPosition = window.scrollY;
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                currentSection = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSection}`) {
                link.classList.add('active');
            }
        });
    }
    
    // Update navigation on scroll
    window.addEventListener('scroll', updateNavigation);
    
    // ===== PERFORMANCE OPTIMIZATION =====
    
    // Throttle scroll events
    function throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        }
    }
    
    // Apply throttling to scroll events
    window.addEventListener('scroll', throttle(updateNavigation, 100));
    
    // ===== INITIALIZATION =====
    
    // Initialize all functionality
    function init() {
        initGallery();
        updateNavigation();
        
        // Add loading animation
        document.body.classList.add('loaded');
    }
    
    // Start initialization
    init();
    
    // ===== UTILITY FUNCTIONS =====
    
    // Debounce function for performance
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Check if element is in viewport
    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
    
    // ===== ERROR HANDLING =====
    
    // Global error handler
    window.addEventListener('error', function(e) {
        console.error('JavaScript error:', e.error);
        showNotification('An error occurred. Please refresh the page.', 'error');
    });
    
    // ===== ACCESSIBILITY =====
    
    // Focus management for keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-navigation');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-navigation');
    });
    
    // ===== RESPONSIVE HELPERS =====
    
    // Check if device is mobile
    function isMobile() {
        return window.innerWidth <= 768;
    }
    
    // Check if device supports touch
    function isTouchDevice() {
        return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    }
    
    // ===== EXPORT FOR DEBUGGING =====
    
    // Make functions available globally for debugging
    window.portfolioDebug = {
        nextProject,
        prevProject,
        goToProject,
        currentProjectIndex: () => currentProjectIndex,
        showNotification
    };
    
});

// ===== ADDITIONAL CSS FOR NOTIFICATIONS =====
const notificationStyles = `
    .notification-close {
        background: none;
        border: none;
        color: white;
        font-size: 1.5rem;
        cursor: pointer;
        margin-left: 1rem;
        padding: 0;
        line-height: 1;
    }
    
    .notification-close:hover {
        opacity: 0.8;
    }
    
    .nav-link.active {
        color: #ffffff !important;
    }
    
    .nav-link.active::after {
        width: 100% !important;
    }
    
    .keyboard-navigation *:focus {
        outline: 2px solid #ffffff;
        outline-offset: 2px;
    }
`;

// Inject notification styles
const styleSheet = document.createElement('style');
styleSheet.textContent = notificationStyles;
document.head.appendChild(styleSheet);
