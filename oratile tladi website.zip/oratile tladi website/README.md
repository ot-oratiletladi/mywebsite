# Oratile Tladi - Portfolio Website

A modern, responsive portfolio website built with HTML, CSS, and JavaScript featuring a dark glassmorphism design aesthetic.

## 🚀 Features

- **Modern Design**: Black and gray blur gradient background with glassmorphism UI elements
- **Responsive Layout**: Mobile-first design that works perfectly on all devices
- **Interactive Gallery**: Horizontal scrolling project showcase with touch/swipe support
- **Smooth Animations**: Subtle animations and transitions throughout the interface
- **Contact Form**: Functional contact form with validation and notifications
- **Accessibility**: Keyboard navigation and screen reader support
- **Performance**: Optimized code with smooth scrolling and efficient animations

## 🛠️ Technologies Used

- **HTML5**: Semantic markup structure
- **CSS3**: Modern CSS with glassmorphism effects, gradients, and animations
- **JavaScript (ES6+)**: Interactive functionality, touch gestures, and form handling
- **Responsive Design**: CSS Grid and Flexbox for modern layouts
- **Touch Support**: Mobile-friendly swipe gestures and touch events

## 📁 File Structure

```
oratile-tladi-portfolio/
├── index.html          # Main HTML file
├── css/
│   └── style.css      # Main stylesheet
├── js/
│   └── main.js        # JavaScript functionality
├── images/             # Project images and assets
└── README.md           # This file
```

## 🚀 Getting Started

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- A local web server (optional, for development)

### Installation

1. **Clone or Download** the project files to your local machine
2. **Navigate** to the project directory
3. **Open** `index.html` in your web browser

### Local Development Server (Optional)

For the best development experience, use a local server:

```bash
# Using Python 3
python -m http.server 8000

# Using Node.js (if you have it installed)
npx serve .

# Using PHP
php -S localhost:8000
```

Then open `http://localhost:8000` in your browser.

## 🎨 Customization

### Colors and Theme

The website uses CSS custom properties for easy color customization. Main colors are defined in `css/style.css`:

```css
/* Primary colors */
--primary-bg: #0a0a0a;
--secondary-bg: #1a1a1a;
--accent-color: #ffffff;
--text-color: #ffffff;
```

### Content Updates

#### Personal Information
- Update the name "ORATILE TLADI" in `index.html`
- Modify contact information in the contact section
- Update social media links in the sidebar

#### Portfolio Projects
- Replace placeholder images in the `images/` folder
- Update project descriptions and titles
- Modify the number of projects in the gallery

#### Styling
- Adjust fonts by changing the Google Fonts import in `index.html`
- Modify spacing and layout in `css/style.css`
- Update animations and transitions as needed

### Adding New Projects

1. **Add Image**: Place your project image in the `images/` folder
2. **Update HTML**: Add a new `.project-item` in the gallery section
3. **Update Navigation**: Add a new dot in the gallery dots section
4. **Update JavaScript**: The gallery will automatically handle the new project

Example new project item:
```html
<div class="project-item">
    <div class="project-image">
        <img src="images/your-project.jpg" alt="Your Project" class="project-img">
        <div class="project-overlay">
            <h3>Your Project Title</h3>
            <p>Project description</p>
        </div>
    </div>
</div>
```

## 📱 Responsive Design

The website is fully responsive with breakpoints at:
- **Desktop**: 1200px and above
- **Tablet**: 768px - 1199px
- **Mobile**: Below 768px

### Mobile Features
- Touch-friendly swipe gestures for the project gallery
- Optimized navigation for small screens
- Responsive typography and spacing
- Hidden sidebar elements on mobile for better UX

## 🎯 Browser Support

- **Modern Browsers**: Chrome 80+, Firefox 75+, Safari 13+, Edge 80+
- **Mobile Browsers**: iOS Safari 13+, Chrome Mobile 80+
- **Features**: CSS Grid, Flexbox, CSS Custom Properties, ES6+

## 🔧 JavaScript Features

### Gallery Functionality
- **Touch Support**: Swipe left/right to navigate projects
- **Mouse Support**: Click and drag to navigate projects
- **Keyboard Support**: Arrow keys and spacebar navigation
- **Auto-play**: Optional automatic project rotation

### Form Handling
- **Validation**: Client-side form validation
- **Notifications**: Success/error message display
- **Accessibility**: Proper form labels and error handling

### Performance Optimizations
- **Throttled Scroll Events**: Optimized scroll performance
- **Intersection Observer**: Efficient scroll animations
- **Touch Event Handling**: Smooth mobile interactions

## 🎨 Design System

### Typography
- **Primary Font**: Inter (Google Fonts)
- **Fallbacks**: System fonts for optimal performance
- **Hierarchy**: Clear typographic scale for headings and body text

### Spacing
- **Base Unit**: 1rem (16px)
- **Scale**: Consistent spacing using rem units
- **Responsive**: Adaptive spacing for different screen sizes

### Animations
- **Duration**: 0.3s for micro-interactions, 0.8s for page animations
- **Easing**: CSS cubic-bezier for smooth, natural motion
- **Performance**: Hardware-accelerated transforms and opacity changes

## 🚀 Deployment

### Static Hosting
The website can be deployed to any static hosting service:

- **GitHub Pages**: Free hosting for GitHub repositories
- **Netlify**: Drag and drop deployment with custom domains
- **Vercel**: Fast deployment with automatic builds
- **AWS S3**: Scalable static website hosting

### Custom Domain
1. Purchase a domain name
2. Configure DNS settings to point to your hosting provider
3. Update any hardcoded URLs in the code

## 🔍 SEO and Performance

### SEO Features
- Semantic HTML structure
- Meta descriptions and titles
- Proper heading hierarchy
- Alt text for images

### Performance Features
- Optimized CSS and JavaScript
- Efficient animations and transitions
- Responsive images
- Minimal external dependencies

## 🐛 Troubleshooting

### Common Issues

#### Images Not Loading
- Check that image files exist in the `images/` folder
- Verify image file names match the HTML src attributes
- Ensure image files are not corrupted

#### Gallery Not Working
- Check browser console for JavaScript errors
- Verify that all gallery elements have correct classes
- Ensure JavaScript file is properly loaded

#### Styling Issues
- Clear browser cache and refresh
- Check CSS file path in HTML
- Verify CSS syntax for any recent changes

### Debug Mode

The website includes a debug mode accessible via the browser console:

```javascript
// Access debug functions
portfolioDebug.nextProject();
portfolioDebug.prevProject();
portfolioDebug.showNotification('Test message', 'success');
```

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📞 Support

For support or questions:
- Check the troubleshooting section above
- Review the code comments for implementation details
- Open an issue on the project repository

## 🔄 Updates and Maintenance

### Regular Maintenance
- Update dependencies and libraries
- Test on new browser versions
- Optimize images and assets
- Review and update content

### Future Enhancements
- Add dark/light theme toggle
- Implement blog section
- Add project filtering and search
- Integrate with CMS for content management

---

**Built with ❤️ for Oratile Tladi**

*Last updated: December 2024*
